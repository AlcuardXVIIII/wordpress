<div id="comments"> 
<?php
		if (!function_exists(duoshuoQuery)) {
			echo "评论：请安装多说插件";
		}
?>
</div>