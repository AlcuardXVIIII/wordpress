SpellForce Patch Readme

Fixes

- This patch fixes a problem that prevents the game from being launched. 

Installation Instructions

1. Install SpellForce to your hard drive. 
2. Locate the SpellForce folder that is installed on your hard drive. 
(Default location is C:\Program Files\JoWooD\SpellForce)
3. Simply replace the SpellForce.exe with the new SpellForce.exe provided in this patch.

For any questions or concerns Please contact:
Aspyr Technical Support
(512)708-8100

You can also contact us through our 24 Hour online support form:

www.aspyr.com/contact